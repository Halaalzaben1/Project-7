#define TRUE 1
#define FALSE 0

// ================= STATES  =================
// the number i wrote then just in case we want to use them instead of writing the whole word

#define START_STATE   0   // my robot is at start
#define LINE_STATE    1   // following line state
#define TUNNEL_STATE  2   // inside tunnel
#define PATH_STATE    3   // path after tunnel
#define PARK_STATE    4   // approaching parking
#define STOP_STATE    5   // stop robot

unsigned char state = START_STATE;   // keep track of current state

// ================= DEFINES =================
#define IR_SENSOR_MASK 0x01   // RB0 -> front IR sensor
#define ir_ActiveLow 1        // 1 means sensor is active low
#define IR_LEFT_OBJ_MASK 0x20   // RB5 -> left object sensor
#define IR_RIGHT_OBJ_MASK 0x80  // RB7 -> right object sensor

#define IR_CENTER_MASK 0x02 // RB1 center line sensor (active low)
#define IR_LEFT_MASK  0x08  // RB3 left line sensor
#define IR_RIGHT_MASK 0x10  // RB4 right line sensor

#define US_TRIG_MASK 0x10   // RC4 ultrasonic trigger
#define US_ECHO_MASK 0x20   // RC5 ultrasonic echo

#define ldr_channel 0x00    // RA0 analog input for LDR
#define BUZZER_MASK  0x40   // RB6 buzzer pin
#define ldr_threshold_on 450
#define ldr_threshold_oFF 550

#define SERVO_PIN RD2_bit    // RD2 for servo

#define POWER_LED_ON()   (PORTD |= 0x01)     // turn LED on
#define POWER_LED_OFF()  (PORTD &= ~0x01)    // turn LED off

// ================= MOTOR PINS =================
#define IN1 RC0_bit   // Left motor input 1
#define IN2 RD4_bit   // Left motor input 2
#define IN3 RD5_bit   // Right motor input 1
#define IN4 RC3_bit   // Right motor input 2

// PWM
// ENA -> RC2 / CCP1  (Left motor speed control)
// ENB -> RC1 / CCP2  (Right motor speed control)

// ================= GLOBAL VARIABLES =================
unsigned char left_base_speed = 35; // left motor speed base
unsigned char right_base_speed = 25; // right motor speed base

volatile unsigned int ms_counter = 0; // counter for delay_ms

unsigned char path_entry = 0;   // flag to do a gentle right after tunnel

unsigned char us_prev_close = 0;  // previous ultrasonic status
unsigned char us_close = 0;       // current ultrasonic status

unsigned char lineL = 0, lineC = 0, lineR = 0; // line sensor status

unsigned int servo_i;   // counter for servo pulse

// ================= HARDWARE PWM INIT =================
void pwm_init(){
    TRISC &= ~(0x06);   // RC1, RC2 as output for PWM

    PR2 = 124;          // set PWM period almost 4kHz
    T2CON = 0x05;       // Timer2 on, prescaler 4

    CCP1CON = 0x0C;     // configure CCP1 for PWM
    CCP2CON = 0x0C;     // configure CCP2 for PWM

    CCPR1L = 0;         // start duty cycle 0
    CCPR2L = 0;
}

// ================= MOTOR SPEED =================
void update_motor_speed(){
    unsigned int pwmL, pwmR;
    if(left_base_speed > 100) left_base_speed = 100;   // cap speed
    if(right_base_speed > 100) right_base_speed = 100;
    pwmL = (left_base_speed * 255) / 100;  // convert % to 8-bit PWM
    pwmR = (right_base_speed * 255) / 100;

    CCPR1L = pwmL; // set left motor speed
    CCPR2L = pwmR; // set right motor speed
}

// ================= DELAY =================
void delay_ms(unsigned int ms){
    ms_counter = ms;          // set counter
    while(ms_counter > 0);    // wait for interrupt to decrease
}

void delay_us(unsigned int us){
   // simple microsecond delay using NOPs
    while(us--){
        asm nop;  // do nothing ~ 0.5 us
        asm nop;  // 2 NOPs = ~ 1 us
    }
}

// ================= INTERRUPT =================
void interrupt(){
    if(TMR0IF_bit){        // check TMR0 overflow
        TMR0IF_bit = 0;    // clear flag
        TMR0 = 6;          // reload timer
        if(ms_counter > 0) ms_counter--; // decrease ms counter
    }
}

// ================= MOTORS =================
void motor_stop(){
    IN1=0; IN2=0; IN3=0; IN4=0; // stop both motors
}

void motor_forward(){
    IN1=1; IN2=0; IN3=1; IN4=0; // move forward
}

void motor_left(){
    IN1=0; IN2=1; IN3=1; IN4=0; // turn left
}

void motor_right(){
    IN1=1; IN2=0; IN3=0; IN4=1; // turn right
}

// ================= LINE FOLLOW =================
void line_follow(){
    unsigned char L = ((PORTB & IR_LEFT_MASK) == 0);  // read left sensor
    unsigned char R = ((PORTB & IR_RIGHT_MASK) == 0); // read right sensor

    if(L && R) motor_forward();    // both sensors on line -> forward
    else if(L && !R) motor_left(); // left sensor only -> turn left
    else if(!L && R) motor_right();// right sensor only -> turn right
    else if(!L && !R) motor_right();// no sensor -> turn right default
    else motor_stop();             // safety
}

//------------------IR sensor Object Detect (front) -----------//
unsigned char ir_sensor_read(){
    if((PORTB & IR_SENSOR_MASK) == 0x00){
        return 1;   // object detected
    }else{
        return 0;   // nothing
    }
}
//------------------IR sensor Object Detect (left) -----------//
unsigned char ir_left_object_read(){
    if((PORTB & IR_LEFT_OBJ_MASK) == 0x00){
        return 1;   // object on left
    }else{
        return 0;
    }
}
unsigned char ir_right_object_read(){
    if((PORTB & IR_RIGHT_OBJ_MASK) == 0x00){
        return 1;   // object on right
    }else{
        return 0;
    }
}

void avoid_left_obstacle(){
    if(ir_left_object_read()){
        motor_left();     // turn right to avoid left wall
        delay_ms(50);     // small delay
    }
}

void avoid_front_obstacle(){
    if(ir_sensor_read()){
        motor_left();     // turn right to avoid front
        delay_ms(100);    // small turn
    }else{
        motor_forward();  // clear path
    }
}

void avoid_right_obstacle(){
    if(ir_right_object_read()){
        motor_right();    // turn left to avoid right
        delay_ms(100);
    }
}

//------------------ldr sensor + Buzzer  -----------//
unsigned int read_LDR(void) {
    ADCON0 = 0x01;          // select AN0, ADC on
    delay_us(20);            // wait a little for ADC
    GO_DONE_bit = 1;         // start conversion
    while (GO_DONE_bit);     // wait until done
    return ((unsigned int)ADRESH << 8) | ADRESL; // read value
}

// ================= ULTRASONIC (HC-SR04) =================
// returns 1 if distance <=20cm
unsigned char ultrasonic_close_20cm(void)
{
    unsigned int tmr;
    unsigned long time_us;
    unsigned int dist_cm;
    unsigned int timeout;

    PORTC &= ~US_TRIG_MASK;  // TRIG low
    delay_us(2);

    PORTC |= US_TRIG_MASK;   // TRIG high 10us
    delay_us(10);
    PORTC &= ~US_TRIG_MASK;  // TRIG low again

    timeout = 0;
    while ((PORTC & US_ECHO_MASK) == 0){ // wait for echo
        timeout++;
        delay_us(1);
        if (timeout > 30000) return 0; // nothing detected
    }

    // start timer1 to measure pulse width
    T1CON = 0x00; TMR1H=0; TMR1L=0; T1CON=0x01;

    timeout = 0;
    while ((PORTC & US_ECHO_MASK) != 0){ // wait echo low
        timeout++;
        delay_us(1);
        if(timeout>30000) break;
    }
    T1CON = 0x00; // stop timer

    tmr = ((unsigned int)TMR1H << 8) | TMR1L; // read timer

#ifndef FOSC_MHZ
#define FOSC_MHZ 8
#endif

#if (FOSC_MHZ==8)
    time_us = (unsigned long)tmr / 2; // 8MHz -> 0.5us per tick
#else
    time_us = (unsigned long)tmr;     // 4MHz -> 1us per tick
#endif

    dist_cm = (unsigned int)(time_us / 58); // distance formula

    if(dist_cm <= 25) return 1;
    else return 0;
}

void raise_servo(){
    unsigned int i;
    for(i=0;i<50;i++){           // 50 pulses ~1s
        PORTD |= 0x04;           // servo high
        delay_us(2000);          // 2ms pulse
        PORTD &= ~0x04;          // servo low
        delay_us(18000);         // rest of 20ms period
    }
}

void full_stop(void){
    motor_stop();          // stop motors
    CCPR1L = 0;            // left PWM off
    CCPR2L = 0;            // right PWM off
    left_base_speed=0;     // zero speed
    right_base_speed=0;
}

// ================= MAIN =================
void main(){
    unsigned char front_hit, left_hit, right_hit;
    unsigned int ldr_value;
    unsigned char was_dark = 0;
    unsigned char done = 0;

    ADCON1=0x86;   // all digital except AN0
    CMCON=0x07;    // disable comparators
    ADCON0=0x01;   // enable ADC

    TRISA |=0x01;  // RA0 input for LDR

    TRISB |= (IR_SENSOR_MASK | IR_CENTER_MASK | IR_LEFT_OBJ_MASK | IR_LEFT_MASK | IR_RIGHT_MASK | IR_RIGHT_OBJ_MASK); // inputs

    TRISB &= ~BUZZER_MASK;   // buzzer output
    TRISB |= IR_RIGHT_OBJ_MASK;   // right IR input

    TRISD &= ~(0x30 | 0x04 | 0x01); // RD4,RD5,RD2,RD0 outputs

    PORTB &= ~BUZZER_MASK; // buzzer off
    TRISC &= ~(0x1F);      // RC0-RC4 outputs
    TRISC |= 0x20;         // RC5 input (echo)

    PORTC = 0x00;
    PORTC &= ~US_TRIG_MASK; // TRIG low
    PORTD = 0x00;
    POWER_LED_ON();          // LED on at start
    PORTB &= ~BUZZER_MASK;   // buzzer off

    pwm_init();              // init PWM
    OPTION_REG = 0b00000100;
    TMR0 = 6;
    TMR0IE_bit=1;
    GIE_bit=1;

    delay_ms(1000);          // wait 1 sec

   while(1){
    // if robot is in STOP_STATE, just stop everything forever
    if(state == STOP_STATE){
        full_stop();        // make sure motors are off
        POWER_LED_OFF();    // turn off power LED
        while(1);           // freeze here, robot stops forever
    }

    update_motor_speed();    // update motor speed according to current base speed

    ldr_value = read_LDR();  // read light sensor
    if(ldr_value < 500){     // dark area detected (like tunnel)
        PORTB &= ~BUZZER_MASK;   // buzzer ON to indicate darkness
        was_dark = 1;            // remember we passed dark spot
        if(state == LINE_STATE) state = TUNNEL_STATE;  // move to TUNNEL_STATE
    } else {                   // light detected
        PORTB |= BUZZER_MASK;   // buzzer OFF
        if(was_dark && state == TUNNEL_STATE){
            state = PATH_STATE; // exited tunnel, move to PATH_STATE
            was_dark = 0;       // reset flag so it triggers only once
        }
    }

    // --------- STATE MACHINE ---------
    switch(state){
        case START_STATE:
            left_base_speed = 0; right_base_speed = 0;
            motor_stop();          // wait at start
            delay_ms(3000);        // give 3s pause at start
            left_base_speed = 25; right_base_speed = 35; // set initial speed
            state = LINE_STATE;    // move to line following
            break;

        case LINE_STATE:
            left_base_speed = 25; right_base_speed = 35;
            // line following behavior
            // robot reads left and right line sensors and adjusts motors
            line_follow();
            break;

        case TUNNEL_STATE:
            left_base_speed = 25; right_base_speed = 35;
            // inside tunnel: follow the line
            line_follow();
            break;

        case PATH_STATE:
            left_base_speed = 25; right_base_speed = 30; // slightly slower
            // check line sensors
            lineL = ((PORTB & IR_LEFT_MASK) == 0);
            lineC = ((PORTB & IR_CENTER_MASK) == 0);
            lineR = ((PORTB & IR_RIGHT_MASK) == 0);

            // if all sensors are off line (no black line), might be end of path
            if(!lineL && !lineC && !lineR){
                delay_ms(300); // debounce, wait a little
                lineL = ((PORTB & IR_LEFT_MASK) == 0);
                lineC = ((PORTB & IR_CENTER_MASK) == 0);
                lineR = ((PORTB & IR_RIGHT_MASK) == 0);
                if(!lineL && !lineC && !lineR){
                    state = PARK_STATE; // go to parking
                    break;
                }
            }

            // ultrasonic + IR obstacle avoidance
            if(us_close && !us_prev_close){
                // detected a wall or obstacle suddenly
                left_hit = ir_left_object_read();
                right_hit = ir_right_object_read();
                motor_stop(); delay_ms(80);  // small pause
                if(right_hit){
                    motor_left(); delay_ms(120);  // turn left if obstacle on right
                } else {
                    motor_right(); delay_ms(120); // turn right if obstacle on left or front
                }
                motor_forward(); delay_ms(250);   // move forward a bit
                us_prev_close = us_close;         // remember current US state
                break;
            }

            us_prev_close = us_close;  // update US latch
            if(us_close){ motor_stop(); break; } // stop if still close

            // normal IR avoidance
            front_hit = ir_sensor_read();
            left_hit = ir_left_object_read();
            right_hit = ir_right_object_read();

            if(front_hit){ avoid_front_obstacle(); break; }
            if(left_hit){ avoid_left_obstacle(); break; }
            if(right_hit){ avoid_right_obstacle(); break; }

            // if no obstacles, continue line follow
            line_follow();
            break;

        case PARK_STATE:
            left_base_speed = 20; right_base_speed = 20; // slow for parking
            motor_forward(); delay_ms(500); // move forward a bit
            motor_left(); delay_ms(450);    // turn into parking spot
            motor_stop(); delay_ms(100);    // small settle
            full_stop(); raise_servo();     // stop and raise flag
            POWER_LED_OFF();                 // indicate finished
            state = STOP_STATE;              // stop robot
            break;

        case STOP_STATE:
            full_stop();                     // make sure everything off
            while(1);                        // stay stopped forever
    }
}

}

