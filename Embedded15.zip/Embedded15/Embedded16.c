#define TRUE 1
#define FALSE 0
 //MAKE AN INTERRUPT BEEP EVERY 500MS CHAT!!!
// ================= STATES =================
// ================= STATES  =================
#define START_STATE   0
#define LINE_STATE    1
#define TUNNEL_STATE  2
#define PATH_STATE    3
#define PARK_STATE    4
#define STOP_STATE    5

unsigned char state = START_STATE;   // current state

// ================= DEFINES =================
#define IR_SENSOR_MASK 0x01   // RB0
#define ir_ActiveLow 1
#define IR_LEFT_OBJ_MASK 0x20   // RB5 (left object detector)
#define IR_RIGHT_OBJ_MASK 0x80   // RB7


#define IR_CENTER_MASK 0x02   // RB1 center line sensor (active low)
#define IR_LEFT_MASK  0x08  // RB3
#define IR_RIGHT_MASK 0x10  // RB4

//////////////////////////////////#define trig_mask 0x02      // RB1
///////////////////////////////////#define echo_mask 0x04      // RB2
#define US_TRIG_MASK 0x10   // RC4
#define US_ECHO_MASK 0x20   // RC5



#define ldr_channel 0x00    // RA0
#define BUZZER_MASK  0x40   // RB6 (bit 6)
#define ldr_threshold_on 450
#define ldr_threshold_oFF 550

#define SERVO_PIN RD2_bit    //RD2

#define POWER_LED_ON()   (PORTD |= 0x01)     // RD0 = 1
#define POWER_LED_OFF()  (PORTD &= ~0x01)    // RD0 = 0

// ================= MOTOR PINS =================
#define IN1 RC0_bit   // Left motor
#define IN2 RD4_bit   // Left motor
#define IN3 RD5_bit   // Right motor
#define IN4 RC3_bit   // Right motor

// PWM
// ENA -> RC2 / CCP1
// ENB -> RC1 / CCP2

// ================= GLOBAL VARIABLES =================
unsigned char left_base_speed = 35; // slightly slower
unsigned char right_base_speed = 25; // slightly faster

volatile unsigned int ms_counter = 0;

unsigned char path_entry = 0;   // do gentle right ONCE after tunnel


unsigned char us_prev_close = 0;
unsigned char us_close = 0;

unsigned char lineL = 0, lineC = 0, lineR = 0;

 unsigned int servo_i;   // ? declare it first (or global)



// ================= HARDWARE PWM INIT =================
void pwm_init(){
    TRISC &= ~(0x06);   // RC1, RC2 outputs

    PR2 = 124;          // ~4 kHz PWM
    T2CON = 0x05;       // Timer2 ON, prescaler 4

    CCP1CON = 0x0C;
    CCP2CON = 0x0C;

    CCPR1L = 0;
    CCPR2L = 0;
}

// ================= MOTOR SPEED =================
void update_motor_speed(){
    unsigned int pwmL, pwmR;
    if(left_base_speed > 100) left_base_speed = 100;
    if(right_base_speed > 100) right_base_speed = 100;
    pwmL = (left_base_speed * 255) / 100;
    pwmR = (right_base_speed * 255) / 100;

    CCPR1L = pwmL; // Left motor (RC2)
    CCPR2L = pwmR; // Right motor (RC1)
}

// ================= DELAY =================
void delay_ms(unsigned int ms){
    ms_counter = ms;
    while(ms_counter > 0);
}

// ================= INTERRUPT =================
void interrupt(){
    if(TMR0IF_bit){
        TMR0IF_bit = 0;
        TMR0 = 6;
        if(ms_counter > 0) ms_counter--;
    }
}

// ================= MOTORS =================
void motor_stop(){
    IN1=0; IN2=0; IN3=0; IN4=0;
}

void motor_forward(){
    IN1=1; IN2=0;
    IN3=1; IN4=0;
}

void motor_left(){
    IN1=0; IN2=1;
    IN3=1; IN4=0;
}

void motor_right(){
    IN1=1; IN2=0;
    IN3=0; IN4=1;
}

// ================= LINE FOLLOW =================
void line_follow(){
    unsigned char L = ((PORTB & IR_LEFT_MASK) == 0);
    unsigned char R = ((PORTB & IR_RIGHT_MASK) == 0);

    if(L && R) motor_forward();
    else if(L && !R) motor_left();
    else if(!L && R) motor_right();
    else if(!L && !R) motor_right();
    else motor_stop();
}
//------------------IR sensor Object Detect (front) -----------//
unsigned char ir_sensor_read(){
    if((PORTB & IR_SENSOR_MASK) == 0x00){
        return 1;   // Object detected
    }else{
        return 0;   // No object
    }
}
//------------------IR sensor Object Detect (left) -----------//
unsigned char ir_left_object_read(){
    if((PORTB & IR_LEFT_OBJ_MASK) == 0x00){
        return 1;   // Object detected on left
    }else{
        return 0;   // No object on left
    }
}
unsigned char ir_right_object_read(){
         if((PORTB & IR_RIGHT_OBJ_MASK) == 0x00){
                   return 1;
         }else{
         return 0;
}
}
void avoid_left_obstacle(){
    if(ir_left_object_read()){
        motor_left();     // turn right to avoid left wall/object
        delay_ms(50);
    }
}
void avoid_front_obstacle(){
    if(ir_sensor_read()){
        motor_left();     // avoid obstacle (turn right)
        delay_ms(100);     // short turn
    }else{
        motor_forward();   // no obstacle
    }
}
void avoid_right_obstacle(){
     if(ir_right_object_read()){
     motor_right();
      delay_ms(100);
}
}

//------------------ldr sensor + Buzzer  -----------//

unsigned int read_LDR(void) {
    ADCON0 = 0x01;          // Select AN0, ADC ON
    Delay_us(20);
    GO_DONE_bit = 1;
    while (GO_DONE_bit);
    return ((unsigned int)ADRESH << 8) | ADRESL;
}



// ================= ULTRASONIC (HC-SR04) =================
// TRIG: RC4 (US_TRIG_MASK)
// ECHO: RC5 (US_ECHO_MASK)
//
// Returns 1 if distance <= 20 cm, else 0

unsigned char ultrasonic_close_20cm(void)
{
    unsigned int tmr;
    unsigned long time_us;
    unsigned int dist_cm;
    unsigned int timeout;

    // Ensure TRIG is low
    PORTC &= ~US_TRIG_MASK;
    Delay_us(2);

    // -------- Trigger pulse 10us --------
    PORTC |= US_TRIG_MASK;
    Delay_us(10);
    PORTC &= ~US_TRIG_MASK;

    // -------- Wait for ECHO to go HIGH (start of pulse) --------
    timeout = 0;
    while ((PORTC & US_ECHO_MASK) == 0)
    {
        timeout++;
        Delay_us(1);
        if (timeout > 30000) return 0; // no echo
    }

    // -------- Start Timer1 (measure HIGH time) --------
    // Timer1 clock = Fosc/4
    // If Fosc=8MHz => tick=0.5us
    // If Fosc=4MHz => tick=1us
    T1CON = 0x00;     // stop, prescaler 1:1
    TMR1H = 0;
    TMR1L = 0;
    T1CON = 0x01;     // TMR1 ON, prescaler 1:1, Fosc/4

    // -------- Wait for ECHO to go LOW (end of pulse) --------
    timeout = 0;
    while ((PORTC & US_ECHO_MASK) != 0)
    {
        timeout++;
        Delay_us(1);
        if (timeout > 30000) break; // safety
    }

    // Stop timer
    T1CON = 0x00;

    // Read Timer1 count
    tmr = ((unsigned int)TMR1H << 8) | TMR1L;

    // Convert counts -> microseconds (depends on Fosc)
    // If Fosc=8MHz: 1 tick = 0.5us => time_us = tmr/2
    // If Fosc=4MHz: 1 tick = 1us   => time_us = tmr
    //
    // You can set this define depending on your oscillator:
    //   #define FOSC_MHZ 8   or 4
#ifndef FOSC_MHZ
#define FOSC_MHZ 8
#endif

#if (FOSC_MHZ == 8)
    time_us = (unsigned long)tmr / 2;
#else
    time_us = (unsigned long)tmr;    // for 4MHz
#endif

    // Distance cm � time_us / 58
    dist_cm = (unsigned int)(time_us / 58);

    // close <= 20cm
    if (dist_cm <= 25) return 1;
    else return 0;
}
void raise_servo(){
    unsigned int i;

    // ~1 second of servo pulses (50 pulses * 20ms)
    for(i = 0; i < 50; i++){
        PORTD |= 0x04;      // RD2 = 1
        Delay_us(2000);     // 2 ms pulse (raise position) 1500-2000 typical
        PORTD &= ~0x04;     // RD2 = 0
        Delay_us(18000);    // rest of 20 ms period
    }
}

void full_stop(void){
    motor_stop();          // direction pins off
    CCPR1L = 0;            // PWM duty = 0
    CCPR2L = 0;
    left_base_speed = 0;
    right_base_speed = 0;
}


// ================= MAIN =================
void main(){

    unsigned char front_hit;
    unsigned char left_hit  ;
    unsigned char right_hit;

    unsigned int ldr_value;
    unsigned char was_dark = 0;
    unsigned char done = 0;




    ADCON1 = 0x86;   // All PORTA & PORTD digital // Right justified, AN0 analog
    CMCON  = 0x07;   // <<< CRITICAL FIX (disables comparators)
    ADCON0 = 0x01;

    TRISA |= 0x01;

  TRISB |= (IR_SENSOR_MASK | IR_CENTER_MASK | IR_LEFT_OBJ_MASK | IR_LEFT_MASK | IR_RIGHT_MASK | IR_RIGHT_OBJ_MASK);

    TRISB &= ~BUZZER_MASK;   // RB6 output
    TRISB |= IR_RIGHT_OBJ_MASK;   // RB7 input

   TRISD &= ~(0x30 | 0x04 | 0x01);   // RD4,RD5,RD2,RD0 outputs



    PORTB &= ~BUZZER_MASK;   // buzzer OFF (active HIGH buzzer)

   TRISC &= ~(0x1F);   // RC0..RC4 outputs (RC4 = TRIG output too)
   TRISC |=  0x20;     // RC5 input (ECHO)


   PORTC = 0x00;
   PORTC &= ~US_TRIG_MASK;   // keep TRIG low after init

    PORTC = 0x00;
    PORTD = 0x00;
    POWER_LED_ON();     // LED ON at power/start
    //PORTD &= ~BUZZER_MASK; // buzzer OFF
     PORTB &= ~BUZZER_MASK;   // OFF
    pwm_init();

    OPTION_REG = 0b00000100;
    TMR0 = 6;
    TMR0IE_bit = 1;
    GIE_bit = 1;

    delay_ms(1000);

    while(1){

    if(state == STOP_STATE){
        full_stop();
        POWER_LED_OFF();
        while(1);   // stop forever
    }


        update_motor_speed();

ldr_value = read_LDR();
if (ldr_value < 500) {      // adjust if needed
            //PORTD &= ~BUZZER_MASK;  // buzzer OFF
             PORTB &= ~BUZZER_MASK;   // buzzer ON (RB6=1)
            was_dark = 1;

    if (state == LINE_STATE)
        state = TUNNEL_STATE;

        }
        // ===== LIGHT =====
        else {
            //PORTD |= BUZZER_MASK;   // buzzer ON
            PORTB |= BUZZER_MASK;    // OFF
            if (was_dark && state == TUNNEL_STATE) {
                state = PATH_STATE;             // exit tunnel -> PATH
                 was_dark = 0;                   // reset so it triggers only once
            }
        }


        switch(state){
        case START_STATE:
            left_base_speed = 0;
            right_base_speed = 0;
            motor_stop();
            delay_ms(3000);
            left_base_speed = 25;
            right_base_speed = 35;
            state = LINE_STATE;
            break;

        case LINE_STATE:

        left_base_speed = 25;
        right_base_speed = 35;


        // --- IR obstacle checks ---
        //front_hit = ir_sensor_read();
        //left_hit  = ir_left_object_read();
        //right_hit = ir_right_object_read();

       //if(front_hit){
       // avoid_front_obstacle();
        //break;   // IMPORTANT: don't override with line_follow()
        //}

        //if(left_hit){
        //avoid_left_obstacle();
        //break;
        //}

        //if(right_hit){
        //avoid_right_obstacle();
        //break;
        //}

        // --- No obstacles => follow the line ---
       line_follow();

       break;
        case TUNNEL_STATE:

        left_base_speed = 25;
        right_base_speed = 35;



      // front_hit = ir_sensor_read();
        //left_hit  = ir_left_object_read();
        //right_hit = ir_right_object_read();

        //if(front_hit){
        //avoid_front_obstacle();
        //break;
        //}

        //if(left_hit){
        //avoid_left_obstacle();
        //break;
        //}

        //if(right_hit){
        //avoid_right_obstacle();
        //break;
        //}

        line_follow();

        break;

        case PATH_STATE:


    left_base_speed  = 25;
    right_base_speed = 30;

    // Read ultrasonic once
            // unsigned char lineL = 0, lineC = 0, lineR = 0;
           lineL = ((PORTB & IR_LEFT_MASK)   == 0);
            lineC = ((PORTB & IR_CENTER_MASK) == 0);
            lineR = ((PORTB & IR_RIGHT_MASK)  == 0);
             if (!lineL && !lineC && !lineR) {
                // simple debounce: confirm it's still 3-black after 60ms
                delay_ms(300);
                lineL = ((PORTB & IR_LEFT_MASK)   == 0);
                lineC = ((PORTB & IR_CENTER_MASK) == 0);
                lineR = ((PORTB & IR_RIGHT_MASK)  == 0);

                if (!lineL && !lineC && !lineR) {
                    state = PARK_STATE;
                    break;
                }
            }

    // ===== Ultrasonic + side IR combined (ONE maneuver only) =====
    // Trigger ONLY on the "rising edge" (far -> close)
    if (us_close && !us_prev_close)
    {
        // Check side IRs at the same moment
        left_hit  = ir_left_object_read();    // RB5
        right_hit = ir_right_object_read();   // RB7

        motor_stop();
        delay_ms(80);

        // Priority:
        // 1) Right IR + US => turn LEFT once
        // 2) Left IR + US  => turn RIGHT once
        // 3) US alone (front wall) => turn RIGHT once
        if (right_hit)
        {
            motor_left();        // turn LEFT once
            delay_ms(120);
        }
        else
        {
            motor_right();       // turn RIGHT once (left wall OR front wall)
            delay_ms(120);
        }

        // Move away so it doesn't re-trigger instantly
        motor_forward();
        delay_ms(250);

        // Update latch + exit this loop iteration
        us_prev_close = us_close;
        break;
    }

    // Update latch every loop
    us_prev_close = us_close;

    // If US is still close (same wall), do NOT run IR avoidance (prevents double-turn)
    if (us_close)
    {
        // optional: keep stopped while too close
        motor_stop();
        break;
    }

    // ===== Ultrasonic is NOT close => IR avoidance works normally =====
    front_hit = ir_sensor_read();
    left_hit  = ir_left_object_read();
    right_hit = ir_right_object_read();

    if(front_hit){
        avoid_front_obstacle();
        break;
    }

    if(left_hit){
        avoid_left_obstacle();
        break;
    }

    if(right_hit){
        avoid_right_obstacle();
        break;
    }

    // ===== No obstacles => follow line normally =====
    line_follow();

    break;
    case PARK_STATE:
            // You asked: forward a little bit, then turn right, then stop.
            left_base_speed  = 20;
            right_base_speed = 20;

            motor_forward();
            delay_ms(500);     // move forward a bit (tune)

            motor_left();
            delay_ms(450);     // turn right (tune for ~90 degrees)

             motor_stop();
            delay_ms(100);       // small settle
             full_stop();
            raise_servo();       // raise flag while stopped
             POWER_LED_OFF();    // LED OFF
            state = STOP_STATE;
            break;

        case STOP_STATE:
         full_stop();        // make sure motors really off (PWM=0 + pins off)
          while(1){
        // stay here forever
        }
}

}
  }


